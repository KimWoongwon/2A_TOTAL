#include "PlayState.h"
#include "MiniGame.h"

CPlayState::CPlayState(CMiniGame* _game) :CGameState(_game)
{
	mTimer = nullptr;	
	mCircleCount = 10;
	mCheckClick = false;
	memset(&mCircleRect, 0, sizeof(RECT));
}


CPlayState::~CPlayState()
{

}

void CPlayState::TimerProcess()
{	
	int radius[] = { 40, 50, 60, 70 };
	RECT crt;
	GetClientRect(CMouse::GetInstance()->GetHWnd(), &crt);
	RECT temprt;

	mCheckClick = false;

	int i = rand() % 4;
	temprt.left = crt.left + radius[i];
	temprt.right = crt.right - radius[i];
	temprt.bottom = crt.bottom - radius[i];
	temprt.top = crt.top + radius[i];
	int x = rand() % (temprt.right - temprt.left) + temprt.left;
	int y = rand() % (temprt.bottom - temprt.top) + temprt.top;
	mCircleRect.left = x - radius[i];
	mCircleRect.top = y - radius[i];
	mCircleRect.right = x + radius[i];
	mCircleRect.bottom = y + radius[i];

	CWindowFrame::GetInstance()->GetBackbit()->ClearBitMap();
	HDC hdc = CWindowFrame::GetInstance()->GetBackbit()->GetBitmapDC();
	Ellipse(hdc, mCircleRect.left, mCircleRect.top, mCircleRect.right, mCircleRect.bottom);
	CWindowFrame::GetInstance()->GetBackbit()->DeleteBitmapDC(hdc);
	InvalidateRect(CMouse::GetInstance()->GetHWnd(), NULL, false);
	mCircleCount--;

	TCHAR Result_Str[128];
	wsprintf(Result_Str, TEXT("%d"), mCircleCount);
	SetWindowText(CMouse::GetInstance()->GetHWnd(), Result_Str);
	
	if (mCircleCount == 0)
	{		
		delete mTimer;
		mTimer = nullptr;
		CWindowFrame::GetInstance()->GetBackbit()->ClearBitMap();
		InvalidateRect(CMouse::GetInstance()->GetHWnd(), NULL, false);

		GetGame()->SetNowState(GetGame()->GetPlayEndState());
	}
}

void CPlayState::ClickProcess()
{
	if (!mCheckClick)
	{
		mCheckClick = true;		

		if (mCircleCount > 0)
		{
			if (PtInRect(&mCircleRect, CMouse::GetInstance()->GetXYPoint()))
			{				
				GetGame()->InCreMentMatchCount();
			}
		}
	}		
}

void CPlayState::InitializeProcess()
{
	mCircleCount = 10;
	GetGame()->ClearMatchCount();
	
	if (mTimer != nullptr)
	{
		delete mTimer;
	}

	mTimer = new CTimer(CMouse::GetInstance()->GetHWnd(), 1000);
	
	PostMessage(CWindowFrame::GetInstance()->GethWnd(), WM_TIMER, mTimer->GetTimerID(),NULL);
	CWindowFrame::GetInstance()->GetButton()->SetCaption(TEXT("�ٽ��ϱ�"));
}

void CPlayState::ButtonProcess()
{	
	this->InitializeProcess();
}
