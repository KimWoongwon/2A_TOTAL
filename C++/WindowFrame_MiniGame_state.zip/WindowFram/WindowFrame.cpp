#include "WindowFrame.h"
#include "MiniGame.h" 
#include "BackBit.h"
#include "Mouse.h"


CWindowFrame* CWindowFrame::mPthis=NULL;

CWindowFrame* CWindowFrame::Create(HINSTANCE _hinstance)
{
	if(!mPthis)
	{
		mPthis=new CWindowFrame();
	}

	mPthis->mhInstance=_hinstance;	

	return mPthis;
}

CWindowFrame* CWindowFrame::GetInstance()
{	
	return mPthis;
}

void CWindowFrame::Destroy()
{
	if(mPthis)
	{
		delete mPthis;
		mPthis=NULL;
	}
}

LRESULT CALLBACK CWindowFrame::WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;		
	
	 CMiniGame* game = CMiniGame::GetInstance();
	
	switch (iMessage)
	{
	case WM_CREATE:
		//CMouse::GetInstance()->Initialize(hWnd);			
		return 0;		
	case WM_TIMER:
		game->TimerProcess();
		return 0;
	case WM_LBUTTONDOWN:
		CMouse::GetInstance()->SetclickDown(lParam);	
		game->ClickProcess();
		return 0; 
	case WM_LBUTTONUP:			
		CMouse::GetInstance()->SetclickUp();
		return 0;
	case WM_COMMAND:
		game->ButtonProcess();
		return 0;
	case WM_MOUSEMOVE:		
		CMouse::GetInstance()->SetXY(lParam);			
		return 0;
	case WM_DESTROY:		
		PostQuitMessage(0);
		return 0;
	case WM_PAINT:		
		hdc=BeginPaint(hWnd, &ps);		
		if (mPthis->mBackBit != nullptr)
		{
			mPthis->mBackBit->SCreanDraw(hdc, 0, 0);
		}		
		EndPaint(hWnd, &ps);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}

void CWindowFrame::Run(MSG _Message)
{
	TranslateMessage(&_Message);
	DispatchMessage(&_Message);
}

void CWindowFrame::Initialize()
{
	mPthis->BuildWindow();

	mButton = new CPushButton();

	RECT crt;
	GetClientRect(CWindowFrame::GetInstance()->GethWnd(), &crt);
	mBackBit = new CBackBit(CWindowFrame::GetInstance()->GethWnd(), crt.right, crt.bottom);
}

void CWindowFrame::BuildWindow()
{	
	WNDCLASS WndClass;
	
	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=CWindowFrame::GetInstance()->mhInstance;
	WndClass.lpfnWndProc=CWindowFrame::GetInstance()->WndProc;
	WndClass.lpszClassName=TEXT("exam");
	WndClass.lpszMenuName=nullptr;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	mhWnd=CreateWindow(TEXT("exam"),TEXT("exam"),WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,mhInstance,NULL);

	ShowWindow(mhWnd, SW_SHOW);
}

HWND CWindowFrame::GethWnd()
{
	return mhWnd;
}
HINSTANCE CWindowFrame::GetInstanceHandle()
{
	return mhInstance;
}

CBackBit* CWindowFrame::GetBackbit()
{
	return mBackBit;
}

CPushButton*	CWindowFrame::GetButton()
{
	return mButton;
}