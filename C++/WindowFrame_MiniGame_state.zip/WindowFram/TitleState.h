#pragma once
#include "GameState.h"
#include "Timer.h"
#include "Mouse.h"
#include "resource.h"

class CTitleState :
	public CGameState
{
	HBITMAP     mTitlebit;
	CTimer*		mTimer;
public:
	CTitleState(CMiniGame* _game);
	~CTitleState();

	virtual void TimerProcess();
	virtual void ClickProcess();
	virtual void InitializeProcess();
	virtual void ButtonProcess();
};

