#include "PlayEndState.h"
#include "MiniGame.h"

CPlayEndState::CPlayEndState(CMiniGame* _game) :CGameState(_game)
{
}
CPlayEndState::~CPlayEndState()
{
}

void CPlayEndState::TimerProcess()
{
	
}
void CPlayEndState::ClickProcess()
{
	
}
void CPlayEndState::InitializeProcess()
{
	CWindowFrame::GetInstance()->GetButton()->SetCaption(TEXT("�������"));
}

void CPlayEndState::ButtonProcess()
{
	GetGame()->SetNowState(GetGame()->GetResultState());
}
