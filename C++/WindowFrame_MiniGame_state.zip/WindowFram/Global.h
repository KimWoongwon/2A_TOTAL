#ifndef  _GLOBAL_H
#define  _GLOBAL_H
#include <windows.h>



#endif