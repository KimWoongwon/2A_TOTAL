#pragma once
#include "Global.h"
#include "BackBit.h"
class CMiniGame;

class CGameState
{
private:
	CMiniGame*    mGame;
public:
	CGameState(CMiniGame* );
	~CGameState();

	CMiniGame* GetGame();
	virtual void TimerProcess(){}
	virtual void ClickProcess(){}
	virtual void InitializeProcess(){}
	virtual void ButtonProcess(){}

};

