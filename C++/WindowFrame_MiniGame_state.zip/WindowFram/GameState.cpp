#include "GameState.h"


CGameState::CGameState(CMiniGame* _game)
{
	 mGame = _game; 
}

CMiniGame* CGameState::GetGame()
{
	return mGame;
}

CGameState::~CGameState()
{
}
