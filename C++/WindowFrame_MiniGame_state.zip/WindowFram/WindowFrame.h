#ifndef _CWINDOWFRAME_H
#define _CWINDOWFRAME_H
#include "Global.h"
#include "BackBit.h"
#include "PushButton.h"

class CWindowFrame
{
	static CWindowFrame*	mPthis;

	HWND					mhWnd;	
	HINSTANCE				mhInstance;	
	
	CBackBit*				mBackBit;
	CPushButton*			mButton;

	CWindowFrame()
	{
		mBackBit = nullptr;
		mButton = nullptr;
	}
	~CWindowFrame()	
	{
		if (mBackBit != nullptr)
		{
			delete mBackBit;
		}

		if (mButton != nullptr)
		{
			delete mButton;
		}
	}

public:
	static CWindowFrame* Create(HINSTANCE _hinstance);
	static CWindowFrame* GetInstance();
	static void Destroy();

	static LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam);

	void Run(MSG);
	void Initialize();
	void BuildWindow();


	CBackBit*		GetBackbit();
	CPushButton*	GetButton();
	HWND			GethWnd();
	HINSTANCE		GetInstanceHandle();
};
#endif
