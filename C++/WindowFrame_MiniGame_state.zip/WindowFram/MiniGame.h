#pragma once

#include "Global.h"

#include "TitleState.h"
#include "PlayState.h"
#include "PlayEndState.h"
#include "ResultPlayState.h"


class CMiniGame
{	

	static CMiniGame*	mPthis;

	int				mMatchCount;
	CGameState*		mNowState;
	
	CTitleState*		mTitleState;
	CPlayState*			mPlayState;
	CPlayEndState*		mPlayEndState;
	CResultPlayState*	mResultState;

	CMiniGame();
	~CMiniGame();

public:

	static CMiniGame* Create();
	static CMiniGame* GetInstance();
	static void Destroy();

	void TimerProcess();
	void ClickProcess();
	void InitializeProcess();
	void ButtonProcess();

	CGameState* GetTitleState();
	CGameState* GetPlayState();
	CGameState* GetPlayEndState();
	CGameState* GetResultState();

	
	int			GetMatchCount();

	void InCreMentMatchCount();
	void ClearMatchCount();
	void SetNowState(CGameState*);
};

