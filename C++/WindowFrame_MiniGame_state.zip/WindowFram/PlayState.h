#pragma once
#include "GameState.h"
#include "Timer.h"
#include "Mouse.h"
class CPlayState :	public CGameState
{
	CTimer*		mTimer;
	bool		mCheckClick;
	int			mCircleCount; 
	RECT		mCircleRect;

public:
	CPlayState(CMiniGame*);
	~CPlayState();

	virtual void TimerProcess();
	virtual void ClickProcess();
	virtual void InitializeProcess();
	virtual void ButtonProcess();
};

