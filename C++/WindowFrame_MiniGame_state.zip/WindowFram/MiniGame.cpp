#include "MiniGame.h"

CMiniGame* CMiniGame::mPthis = nullptr;
CMiniGame::CMiniGame()
{	
	mMatchCount = 0;
	mTitleState = new CTitleState(this);
	mPlayState = new CPlayState(this);
	mPlayEndState = new CPlayEndState(this);
	mResultState = new CResultPlayState(this);		
	
	mNowState = nullptr;
}

CMiniGame::~CMiniGame()
{	
	delete mTitleState;
	delete mPlayState;
	delete mPlayEndState;
	delete mResultState;	
}

CMiniGame* CMiniGame::Create()
{
	if (!mPthis)
	{
		mPthis = new CMiniGame();
	}
	return mPthis;
}

CMiniGame* CMiniGame::GetInstance()
{
	return mPthis;
}

void CMiniGame::Destroy()
{	
	if (mPthis)
	{
		delete mPthis;
		mPthis = NULL;
	}
}


void CMiniGame::TimerProcess()
{
	mNowState->TimerProcess();
}
void CMiniGame::ClickProcess()
{
	mNowState->ClickProcess();
}
void CMiniGame::InitializeProcess()
{
	SetNowState(mTitleState);
}
void CMiniGame::ButtonProcess()
{
	mNowState->ButtonProcess();
}


CGameState* CMiniGame::GetTitleState()
{
	return mTitleState;
}
CGameState* CMiniGame::GetPlayState()
{
	return mPlayState;
}
CGameState* CMiniGame::GetPlayEndState()
{
	return mPlayEndState;
}
CGameState* CMiniGame::GetResultState()
{
	return mResultState;
}



int	CMiniGame::GetMatchCount()
{
	return mMatchCount;
}

void CMiniGame::InCreMentMatchCount()
{
	mMatchCount++;
}
void CMiniGame::ClearMatchCount()
{
	mMatchCount = 0;
}
void CMiniGame::SetNowState(CGameState* _state)
{
	mNowState = _state;
	mNowState->InitializeProcess();
}