#include "ResultPlayState.h"
#include "MiniGame.h"

CResultPlayState::CResultPlayState(CMiniGame* _game) : CGameState(_game)
{

}


CResultPlayState::~CResultPlayState()
{
}

void CResultPlayState::TimerProcess()
{

}
void CResultPlayState::ClickProcess()
{

}
void CResultPlayState::InitializeProcess()
{	
	TCHAR  Result_Str[128];
	CWindowFrame::GetInstance()->GetButton()->SetCaption(TEXT("ó������"));

	wsprintf(Result_Str, TEXT("���� :%d "), GetGame()->GetMatchCount());
	HDC hdc = CWindowFrame::GetInstance()->GetBackbit()->GetBitmapDC();
	TextOut(hdc, 300, 300, Result_Str, lstrlen(Result_Str));
	CWindowFrame::GetInstance()->GetBackbit()->DeleteBitmapDC(hdc);
	InvalidateRect(CMouse::GetInstance()->GetHWnd(), NULL, false);
}

void CResultPlayState::ButtonProcess()
{
	GetGame()->SetNowState(GetGame()->GetTitleState());
}
