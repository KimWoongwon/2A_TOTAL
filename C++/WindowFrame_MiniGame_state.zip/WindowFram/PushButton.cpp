#include "PushButton.h"
#include "WindowFrame.h"

CPushButton::CPushButton()
{
	mHWnd = CreateWindow(TEXT("button"), TEXT(""), WS_CHILD | WS_VISIBLE, 
		800, 600, 100, 50, CWindowFrame::GetInstance()->GethWnd(), 0, CWindowFrame::GetInstance()->GetInstanceHandle(), NULL);
}


CPushButton::~CPushButton()
{
}

void CPushButton::SetCaption(TCHAR* _str)
{
	SetWindowText(mHWnd, _str);
}