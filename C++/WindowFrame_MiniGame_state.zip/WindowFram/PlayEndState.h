#pragma once
#include "GameState.h"
#include "WindowFrame.h"


class CPlayEndState :public CGameState
{	

public:
	CPlayEndState(CMiniGame* _game);
	~CPlayEndState();

	virtual void TimerProcess();
	virtual void ClickProcess();
	virtual void InitializeProcess();
	virtual void ButtonProcess();
};

