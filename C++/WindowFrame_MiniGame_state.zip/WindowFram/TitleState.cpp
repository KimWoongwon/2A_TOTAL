#include "TitleState.h"
#include "MiniGame.h" 


void CTitleState::ButtonProcess()
{
	if (mTimer)
	{
		delete mTimer;
		mTimer = nullptr;
	}
	
	GetGame()->SetNowState(GetGame()->GetPlayState());

}

void CTitleState::InitializeProcess()
{
	mTimer = new CTimer(CWindowFrame::GetInstance()->GethWnd(), 100);
	CWindowFrame::GetInstance()->GetButton()->SetCaption(TEXT("���ӽ���"));

}

void CTitleState::TimerProcess()
{
	CBackBit* bit = CWindowFrame::GetInstance()->GetBackbit();
	static int	x = -300;
	x = x + 10;
	if (x >= 200)
	{
		delete mTimer;
		mTimer = nullptr;
		x = -300;
		return;
	}
	
	bit->ClearBitMap();
	bit->BitmapDraw(x, 150, mTitlebit);
	InvalidateRect(bit->GetHWnd(), NULL, false);
}

CTitleState::CTitleState(CMiniGame* _game) :CGameState(_game)
{
	mTimer = nullptr;
	mTitlebit = LoadBitmap(CWindowFrame::GetInstance()->GetInstanceHandle(), MAKEINTRESOURCE(IDB_BITMAP2));
}

CTitleState::~CTitleState()
{
	if (mTimer)
	{
		delete mTimer;
		mTimer = nullptr;
	}
}
void CTitleState::ClickProcess()
{
	if (mTimer)
	{
		delete mTimer;
		mTimer = nullptr;
	}

	GetGame()->SetNowState(GetGame()->GetPlayState());

}