#ifndef _PUSHBUTTON_H
#define	_PUSHBUTTON_H

#include "Global.h"


class CPushButton
{
	HWND	mHWnd;

public:
	CPushButton();
	~CPushButton();
	void SetCaption(TCHAR*);
};

#endif
